#pragma once
enum AccountType
{
	Current = 0,
	Savings = 1,
	Privilege = 2
};