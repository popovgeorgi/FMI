#pragma once
const char* getWordFromString(int wordIndex, const char* string);